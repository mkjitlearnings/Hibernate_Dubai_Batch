package com.eu;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyExecutorService {
	public static void main(String[] args) {
		
		//singleThreadPool();
		fixedThreadPool();
	}

	public static void singleThreadPool()
	{
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		executorService.execute(new Task1());
		executorService.execute(new Thread(new Task2()));
		
		
		executorService.shutdown();
	}

	public static void fixedThreadPool()
	{
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		executorService.execute(new Task(1));
		executorService.execute(new Task(2));
		executorService.execute(new Task(3));
		executorService.execute(new Task(4));
		executorService.execute(new Task(5));
		
		
	}

}
