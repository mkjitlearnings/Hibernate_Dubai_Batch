package com.eu;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class CallableTask implements Callable<String>
{
	String name;
	public CallableTask(String name) {
		super();
		this.name = name;
	}
	public String call() throws Exception {
		
		Thread.sleep(500);
		return "Hello";
	}
}


public class CallableThreadsDemo {
	public static void main(String[] args) {
		ExecutorService executorService = Executors.newFixedThreadPool(1);
		
		Future<String> future = executorService.submit(new CallableTask("Print Task "));
		String str;
		try {
			str = future.get();
			System.out.println(str);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("main completed");
		
	}
	
}
