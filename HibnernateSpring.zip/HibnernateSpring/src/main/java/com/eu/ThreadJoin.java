package com.eu;

class Task extends Thread
{
	private int taskNumber;
	
	public Task(int taskNumber) {
		super();
		this.taskNumber = taskNumber;
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	@Override
	public void run() {
		System.out.println("\nTask "+taskNumber+" Started ");
		for(int i = taskNumber*100;i<taskNumber*100+10;i++)
		{
			System.out.print(i+"  ");
		}
		System.out.println("\nTask "+taskNumber+" Finished");
	}
	

}


class Task1 extends Thread
{

	@Override
	public void run() {
		System.out.println("\nTask 1 Started ");
		for(int i = 100;i<110;i++)
		{
			System.out.print(i+"  ");
		}
		System.out.println("\nTask 1 Finished");
	}
	
}

class Task2 implements Runnable
{

	public void run() {
		System.out.println("\nTask 2 Started ");
		for(int i = 200;i<210;i++)
		{
			System.out.print(i+"  ");
		}
		System.out.println("\nTask 2 Finished");
	}
}


public class ThreadJoin {

	public static void main(String[] args) throws InterruptedException {
		
		Task1 t1 = new Task1();
		t1.setPriority(10);
		t1.start();
		
	
		Task2 task2 = new Task2();
		Thread t2 = new Thread(task2);
		t2.start();
		
		t1.join();
		System.out.println("\n Task 3 Started ");
	
		for(int i = 300;i<310;i++)
		{
			System.out.print(i+"  ");
		}
		
		System.out.println("\n Task 3 Finished");
	
	
	}
}
