package com.ko;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class StudentDAOImpl {
	
	@Autowired
	private SessionFactory factory;
	
	@Transactional
	public Student getStudent()
	{
		Session session = factory.openSession();
		
		Student stu = session.get(Student.class, 1);
		
		return stu;
	}

}
