package com.ko;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		StudentDAOImpl dao = (StudentDAOImpl) context.getBean("studentDAOImpl");
		
		System.out.println(dao.getStudent());
	}
}
